package com.temp.weather;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;

public class Weather {

	public static void main(String[] args) throws IOException, ParseException {
		String input;
		try {
			System.out.println("enter the 5 digit Zip code for USA country");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			while ((input = br.readLine()) != null) {
				try {
					getDetails(input);
				} catch (NumberFormatException e) {
					System.out.println("zip code is not valid");
				}

				System.out.println("want to try again for another zip code ?");

			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void getDetails(String zipcode) throws IOException, ParseException {
		URL url = null;
		try {

			String URL = "http://api.openweathermap.org/data/2.5/weather?zip=".concat(zipcode)
					.concat(",us&appid=68d4994bf3bc8e1863ebb27146cc1e62");
			System.out.println("url is " + URL);
			url = new URL(URL);

			URLConnection con = url.openConnection();

			InputStream is = con.getInputStream();

			BufferedReader ar = new BufferedReader(new InputStreamReader(is));

			String line = null;
			String minTemp = null, maxTemp = null, temp = null;
			line = ar.readLine();
			JSONObject obj = null;
			obj = new JSONObject(line);

			Iterator<?> keys = obj.keys();
			while (keys.hasNext()) {
				String key = (String) keys.next();
				if (key.equalsIgnoreCase("main")) {
					if (obj.get(key) instanceof JSONObject) {
						JSONObject childObj = new JSONObject(obj.get(key).toString());
						minTemp = childObj.get("temp_min").toString();
						maxTemp = childObj.get("temp_max").toString();
						temp = childObj.get("temp").toString();

					}
				}

			}
			System.out.println("minTemp is : " + minTemp);
			System.out.println("minTemp is : " + maxTemp);
			System.out.println("minTemp is : " + temp);

		} catch (IOException e) {
			System.out.println("Wrong input.");
			return;
		} catch (JSONException e) {
			e.printStackTrace();
			System.out.println(" Invalid format.");
		} finally {
			url.openStream().close();

		}

	}
}